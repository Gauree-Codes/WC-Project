﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Mail;

public partial class Receipt : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {
         Literal2.Text = Session["p"].ToString();
          Literal3.Text = Session["pr"].ToString();
          Literal5.Text = Session["to"].ToString();
          ////Literal1.Text = Literal1.Text +"  "+Session["p1"].ToString();
          ////Literal2.Text = Literal2.Text +"  "+Session["pr1"].ToString();
          //Literal3.Text = Session["t1"].ToString();
          Literal4.Text = Session["Q"].ToString();
          Literal6.Text = DateTime.Today.ToString();

          int r;
          try
          {

              con.Open();
              SqlCommand cmd = new SqlCommand("Select max(BillNo) from Recipt", con);
              SqlDataReader dr = cmd.ExecuteReader();

              if (dr.Read())
              {

                  string d = dr[0].ToString();
                  if (d == "")
                  {

                      Literal1.Text = "1";//set the value in textbox which name is id

                  }
                  else
                  {

                      r = Convert.ToInt32(dr[0].ToString());
                      r = r + 1;
                      Literal1.Text = r.ToString();
                  }

              }
              con.Close();
          }
          catch (Exception ex)
          {
              Response.Write("<script> alert (" + ex.Message + ") </script>");
          }

           // Label19.Text = Session["Shipping Charges"].ToString();
          //  Label21.Text = Session["Total"].ToString();
           // Server.Transfer("~/Bill.aspx");
      
    }
    protected void  Button2_Click(object sender, EventArgs e)
{

  try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Recipt(BillNo,Pname,Price,Quantity,Total,Cname,Caddress,Cstate,Clandmark,Cpin,Cmob,Cemail)values(@BillNo,@Pname,@Price,@Quantity,@Total,@Cname,@Caddress,@Cstate,@Clandmark,@Cpin,@Cmob,@Cemail)", con);
            cmd.Parameters.AddWithValue("@BillNo", Literal1.Text);
            cmd.Parameters.AddWithValue("@Pname", Literal2.Text);
            cmd.Parameters.AddWithValue("@Price", Literal3.Text);
            cmd.Parameters.AddWithValue("@Quantity", Literal4.Text);
            cmd.Parameters.AddWithValue("@Total", Literal5.Text);
            cmd.Parameters.AddWithValue("@Cname", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Caddress", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Cstate", DropDownList1.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@Clandmark", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Cpin", TextBox4.Text);
            cmd.Parameters.AddWithValue("@Cmob", TextBox5.Text);
            cmd.Parameters.AddWithValue("@Cemail", TextBox6.Text);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert ('Proced To Payment Succefully') </script>");
            Session["bno"] = Literal1.Text;
            Response.Redirect("concat_Report.aspx");
            Literal1.Text = "";
            Literal2.Text = "";
            Literal3.Text = "";
            Literal4.Text = "";
            Literal5.Text = "";
            TextBox1.Text = "";
            TextBox2.Text = "";
            DropDownList1.SelectedItem.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write("<script> alert (" + ex.Message + ") </script>");
        }
        finally
        {
            con.Close();
        }
}
    protected void Button1_Click(object sender, EventArgs e)
    {

        string prevPage = Request.UrlReferrer.ToString();
        Response.Redirect("qty.aspx");
    }
}
    