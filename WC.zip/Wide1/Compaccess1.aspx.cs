﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Compaccess1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Label11.Text= Session["type"].ToString();
        string a = Session["type"].ToString();
        Session["t"] = a;


    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (GridView1.SelectedRow != null)
        {
            GridViewRow selectedrow = GridView1.SelectedRow;
            Session["pname"] = selectedrow.Cells[0].Text;
            Session["price"] = selectedrow.Cells[1].Text;
            Response.Redirect("~/qty.aspx");
            //   Response.Redirect("~/ComputerAccessories.aspx");
        }
        else
        {
            // Response.Write("<script> alert ('Please Select Row') </script>");
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select a row.')", true);
        }

    }

    protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        if (GridView1.SelectedRow != null)
        {

            GridView1.SelectedRow.ForeColor = System.Drawing.Color.Red;

        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        string prevPage1 = Request.UrlReferrer.ToString();
        Response.Redirect("Products.aspx");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }
    
}