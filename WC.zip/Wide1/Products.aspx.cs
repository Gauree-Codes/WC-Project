﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Products : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton1.Text;

        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton2.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton3.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton4.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton5_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton5.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton6_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton6.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton7_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton7.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton8_Click(object sender, EventArgs e)
    {
        Session["type"] = LinkButton8.Text;
        Response.Redirect("compaccess1.aspx");
    }
    protected void LinkButton9_Click(object sender, EventArgs e)
    {
        Response.Redirect("Homepage.aspx");
    }
}