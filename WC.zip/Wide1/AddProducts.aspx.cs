﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;


public partial class AddProducts : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
        int r;
        try
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("Select max(SrNo) from Products", con);
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {

                string d = dr[0].ToString();
                if (d == "")
                {

                    TextBox1.Text = "1";//set the value in textbox which name is id

                }
                else
                {

                    r = Convert.ToInt32(dr[0].ToString());
                    r = r + 1;
                    TextBox1.Text = r.ToString();
                }

            }
            con.Close();
        }
        catch (Exception ex)
        {
            Response.Write("<script> alert (" + ex.Message + ") </script>");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

        if (FileUpload1.PostedFile != null)
        {

            string FileName = Path.GetFileName(FileUpload1.PostedFile.FileName);



            //Save files to disk

            FileUpload1.SaveAs(Server.MapPath("Photo/" + FileName));


            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into Products(SrNo,ProductName,Type,Price,Quantity,FileName,FilePath)values(@SrNo,@ProductName,@Type,@Price,@Quantity,@FileName,@FilePath)", con);
                cmd.Parameters.AddWithValue("@SrNo", TextBox1.Text);
                cmd.Parameters.AddWithValue("@ProductName", TextBox2.Text);
                cmd.Parameters.AddWithValue("@Type", TextBox3.Text);
                cmd.Parameters.AddWithValue("@Price", TextBox4.Text);
                cmd.Parameters.AddWithValue("@Quantity", TextBox5.Text);
                cmd.Parameters.AddWithValue("@FileName", FileName);
                cmd.Parameters.AddWithValue("@FilePath", "Photo/" + FileName);
                cmd.ExecuteNonQuery();
                Response.Write("<script> alert ('Record Insert Succefully') </script>");
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";

            }
            catch (Exception ex)
            {
                Response.Write("<script> alert (" + ex.Message + ") </script>");
            }
            finally
            {
                con.Close();
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {

        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update Products set SrNo=@SrNo,Type=@Type,Price=@Price,Quantity=@Quantity where ProductName=@ProductName", con);
            cmd.Parameters.AddWithValue("@SrNo", TextBox1.Text);
            cmd.Parameters.AddWithValue("@ProductName", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Type", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Price", TextBox4.Text);
            cmd.Parameters.AddWithValue("@Quantity", TextBox5.Text);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert ('Record Updated Succefully') </script>");

            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";


        }
        catch (Exception ex)
        {
            Response.Write("<script> alert (" + ex.Message + ") </script>");
        }
        finally
        {
            con.Close();
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("delete from Products where SrNo=@SrNo", con);

            cmd.Parameters.AddWithValue("@SrNo", TextBox1.Text);
            cmd.Parameters.AddWithValue("@ProductName", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Discription", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Price", TextBox4.Text);
            cmd.Parameters.AddWithValue("@Quantity", TextBox5.Text);
            cmd.ExecuteNonQuery();
            Response.Write("<script> alert ('Record Deleted Succefully') </script>");

            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write("<script> alert (" + ex.Message + ") </script>");
        }
        finally
        {
            con.Close();
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin View.aspx");
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Adminlogin.aspx");
    }
}