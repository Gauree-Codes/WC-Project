﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;
using System.Data;
using System.Data.SqlClient;

public partial class Gridservices : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowCommand1(object sender, GridViewCommandEventArgs e)
    {
        if (GridView1.SelectedRow != null)
        {

            GridView1.SelectedRow.ForeColor = System.Drawing.Color.Red;

        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        TextBox1.Visible = true;
        Button2.Visible = true;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
        if (GridView1.SelectedRow != null)
        {
            GridViewRow selectedrow = GridView1.SelectedRow;
             string toEmail= selectedrow.Cells[2].Text;
             Sendemail(toEmail);
            //   Response.Redirect("~/ComputerAccessories.aspx");
        }

        //try
        //{
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("insert into Services(Name,Address,Mail,Phone,Message,Date)values(@Name,@Address,@Mail,@Phone,@Message,@Date)", con);
        //    cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
        //    cmd.Parameters.AddWithValue("@Address", TextBox6.Text);
        //    cmd.Parameters.AddWithValue("@Mail", TextBox3.Text);
        //    cmd.Parameters.AddWithValue("@Phone", TextBox4.Text);
        //    cmd.Parameters.AddWithValue("@Message", TextBox5.Text);
        //    cmd.Parameters.AddWithValue("@Date", Literal1.Text);

        //    cmd.ExecuteNonQuery();
        //    Response.Write("<script> alert ('Sending Message Succefully') </script>");
        //    TextBox1.Text = "";
        //    TextBox6.Text = "";
        //    TextBox3.Text = "";
        //    TextBox4.Text = "";
        //    TextBox5.Text = "";
        //    Literal1.Text = "";

        //}
        //catch (Exception ex)
        //{
        //    Response.Write("<script> alert (" + ex.Message + ") </script>");
        //}
        //finally
        //{
        //    con.Close();

        //}

       
    }
    public void Sendemail(string toEmail)
    {
        string to = toEmail;
        string from = "gswide2018@gmail.com";
        string subject = "Wide Communucation";
        string body = TextBox1.Text;
        using (MailMessage mm = new MailMessage(from, to))
        {
            mm.Subject = subject;
            mm.Body = body;
            mm.IsBodyHtml = false;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential(from, "2018gswide");
            smtp.UseDefaultCredentials = true;
            smtp.Credentials = NetworkCred;
            smtp.Port = 587;
            smtp.Send(mm);
            ClientScript.RegisterStartupScript(GetType(), "alert", "alert('Email sent.');", true);
        }
    }
    protected void ImageButton6_Click(object sender, ImageClickEventArgs e)
    {
        Response.Write("Homepage.aspx");
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
}
