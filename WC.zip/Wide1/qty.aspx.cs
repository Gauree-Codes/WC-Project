﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class qty : System.Web.UI.Page

{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    String qt1;
    protected void Page_Load(object sender, EventArgs e)
    {
         
            Literal1.Text = Session["pname"].ToString();
            Literal2.Text = Session["price"].ToString();
            Session["Q"]=TextBox1.Text;
            string a = Session["t"].ToString();
            if (a == "Computer Accessories")
            {
                Label6.Text = "50";
            }
            else if (a == "LCD Writing Board")
            {
                Label6.Text = "50";
            }

            else if (a == "Electrical Water Motor")
            {
                Label6.Text = "300";
            }

            else if (a == "Flash storage Devices")
            {
                Label6.Text = "50";
            }

            else if (a == "Cables")
            {
                Label6.Text = "50";
            }

            else if (a == "TFT Panels")
            {
                Label6.Text = "150";
            }

            else if (a == "Starters")
            {
                Label6.Text = "150";
            }

            else if (a == "Connectors")
            {
                Label6.Text = "50";
            }

       
    }
   
   
    protected void Button2_Click(object sender, EventArgs e)
    {

        


            Double price = Convert.ToDouble(Literal2.Text);
            Double qt = Convert.ToDouble(TextBox1.Text);
            Double ship = Convert.ToDouble(Label6.Text);
         
            Literal3.Text = Convert.ToString((price* qt) + ship);
            Session["total"] = Literal3.Text;
            Session["p"] = Literal1.Text;
            Session["pr"] = Literal2.Text;
            Session["to"] = Literal3.Text;

            try
            {

                SqlCommand cmd = new SqlCommand();
                con.Open();


                cmd = new SqlCommand("select Quantity from Products where (ProductName='" + Session["pname"].ToString() + "')", con);
                cmd.ExecuteNonQuery();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds, "Products");
                DataTable dt = new DataTable();
                dt = ds.Tables["Products"];
                foreach (DataRow dr in dt.Rows)
                {
                    foreach (DataColumn dc in dt.Columns)
                    {
                        Literal4.Text = dr[dc].ToString();
                    }

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            qt1 = (Convert.ToInt32(Literal4.Text) - Convert.ToInt32(TextBox1.Text)).ToString();

            try
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update Products set Quantity=@Quantity where ProductName=@name", con);

                cmd.Parameters.AddWithValue("@Quantity", qt1);
                cmd.Parameters.AddWithValue("@name", Session["pname"].ToString());

                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                Response.Write("<script>alert(" + ex.Message + ")</script>");
            }
            finally
            {
                con.Close();
            }



    

        
    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
            //Session["p"] = Literal1.Text;
            //Session["pr"] = Literal2.Text;
            //Session["total"] = Literal3.Text;
            Response.Redirect("Receipt.aspx");
      
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        string prevPage = Request.UrlReferrer.ToString();
        Response.Redirect("compaccess1.aspx");
    }
   
   
    }
