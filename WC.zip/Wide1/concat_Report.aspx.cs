﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;

public partial class concat_Report : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    SqlDataAdapter da;
    protected void Page_Load(object sender, EventArgs e)
    {
        int b = Convert.ToInt32(Session["bno"]);
        try
        {
            da = new SqlDataAdapter("select * from Recipt where BillNo=" + b + "", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Recipt");
            ReportDocument cp = new ReportDocument();
            cp.Load(Server.MapPath("CrystalReport.rpt"));
            cp.SetDataSource(ds.Tables[0]);
            CrystalReportViewer1.ReportSource = cp;
            CrystalReportViewer1.DataBind();
        }
        catch (Exception ex)
        { }

    }
    protected void CrystalReportViewer1_Init(object sender, EventArgs e)
    {

    }
}