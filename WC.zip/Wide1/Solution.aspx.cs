﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.IO;

public partial class Solution : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {
        Literal1.Text = DateTime.Now.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime d = Convert.ToDateTime(Literal1.Text);
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into Services(Name,Address,Mail,Phone,Message,Cu_date)values(@Name,@Address,@Mail,@Phone,@Message,@Cu_date)", con);
            cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
            cmd.Parameters.AddWithValue("@Address", TextBox2.Text);
            cmd.Parameters.AddWithValue("@Mail", TextBox3.Text);
            cmd.Parameters.AddWithValue("@Phone", TextBox4.Text);
            cmd.Parameters.AddWithValue("@Message", TextBox5.Text);
            cmd.Parameters.AddWithValue("@Cu_date", d);

            cmd.ExecuteNonQuery();
            Response.Write("<script> alert ('Sending Message Succefully') </script>");
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            Literal1.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write("<script> alert (" + ex.Message + ") </script>");
        }
        finally
        {
            con.Close();

        }
    }
}