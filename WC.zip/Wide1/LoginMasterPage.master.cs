﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class LoginMasterPage : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string username = lblusername.Text;
        string password = lblpassword.Text;
        SqlCommand cmd = new SqlCommand("select username,password from login where username='" + lblusername.Text + "'and password='" + lblpassword.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Response.Write("<script> alert('Login Successfully')</script>");
            Response.Redirect("Admin View.aspx");

        }

        else
        {
            Response.Write("<script> alert('Invalid username and password')</script>");

            con.Close();

        }

    }
}

