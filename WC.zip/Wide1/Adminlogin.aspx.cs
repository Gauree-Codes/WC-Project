﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class Adminlogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=.\\sqlexpress;Initial Catalog=Products;Integrated Security=True;Pooling=False");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string username =Label1.Text;
        string password =Label2.Text;
        SqlCommand cmd = new SqlCommand("select UserName,Password from Login where UserName='" + TextBox1.Text + "'and Password='" + TextBox2.Text + "'", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);
        if (dt.Rows.Count > 0)
        {
            Response.Write("<script> alert('Login Successfully')</script>");
            Response.Redirect("Admin View.aspx");

        }

        else
        {
            Response.Write("<script> alert('Invalid username and password')</script>");

            con.Close();

        }

    }
    }